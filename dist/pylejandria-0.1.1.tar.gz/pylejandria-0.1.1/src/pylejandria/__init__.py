#################################
#   MADE BY: ARMANDO CHAPARRO   #
#################################

import gui, math, module, tools, upload

MAFER = """
It´s hard to forget
someone who gave you
so much to remember.
I´ll always love you, Mafer.
"""