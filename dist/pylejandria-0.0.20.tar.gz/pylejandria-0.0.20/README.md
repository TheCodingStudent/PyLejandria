# PyLejandria

Javier and I were bored of always copy-paste functions for our programs, or sometimes
we ended up sendind our functions via whatsapp, so we decided to make a package
to make easier to code easy programs. PyLejandria at this moment has:

* Math
* Tools
* Graph (developing)
* Module

from version 0.0.9 PyLejandria needs python >= 3.9

visit the pypi page to download
[PyLejandria](https://pypi.org/project/pylejandria/)
or use "python -m pip install pylejandria" in terminal.

## ARMANDO CHAPARRO & JAVIER VAZQUEZ