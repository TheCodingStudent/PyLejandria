#################################
#   MADE BY: ARMANDO CHAPARRO   #
#################################

from pylejandria import gui
from pylejandria import math
from pylejandria import module
from pylejandria import tools
from pylejandria import upload
from pylejandria import constants
from pylejandria import auto

MAFER = """
It´s hard to forget
someone who gave you
so much to remember.
I´ll always love you, Mafer.
"""