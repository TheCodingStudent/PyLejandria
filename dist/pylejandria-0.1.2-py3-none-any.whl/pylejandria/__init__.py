#################################
#   MADE BY: ARMANDO CHAPARRO   #
#################################

from pylejandria import gui
from pylejandria import help
from pylejandria import math
from pylejandria import module
from pylejandria import tools
from pylejandria import upload

MAFER = """
It´s hard to forget
someone who gave you
so much to remember.
I´ll always love you, Mafer.
"""