#################################
#   MADE BY: ARMANDO CHAPARRO   #
#################################

import os

MAFER = """
It´s hard to forget
someone who gave you
so much to remember.
I´ll always love you, Mafer.
"""