# PyLejandria

Javier and i were bored of always copy-paste functions for our programs, or sometimes
we ended up sendind our functions via whatsapp, so we decided to make a package
to make easier to code easy programs. PyLejandria at this moment has:

* math
* tools

visit the pypi page to download
[PyLejandria](https://pypi.org/project/pylejandria/)
or use "python -m pip install pylejandria" in terminal.

## ARMANDO CHAPARRO & JAVIER VAZQUEZ